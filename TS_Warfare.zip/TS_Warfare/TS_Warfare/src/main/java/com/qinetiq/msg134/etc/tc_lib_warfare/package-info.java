
/**
 * Contains the base model, configuration and helper functionality.
 * @author QinetiQ
 */
package com.qinetiq.msg134.etc.tc_lib_warfare;