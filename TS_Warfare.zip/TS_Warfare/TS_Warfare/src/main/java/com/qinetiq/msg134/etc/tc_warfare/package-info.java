/**
 * Contains the executable test case
 * @author user
 */
package com.qinetiq.msg134.etc.tc_warfare;