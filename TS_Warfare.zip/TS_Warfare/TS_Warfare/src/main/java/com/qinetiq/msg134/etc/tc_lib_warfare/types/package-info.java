/**
 * Contains the various data types.
 * @author QinetiQ
 */
package com.qinetiq.msg134.etc.tc_lib_warfare.types;